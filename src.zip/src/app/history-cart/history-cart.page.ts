import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Router,ActivatedRoute } from "@angular/router";
import { LoadingController } from '@ionic/angular';

import { Storage } from '@ionic/storage-angular';
import { AuthenticationService } from '../_services/authentication.service';

@Component({
  selector: 'app-history-cart',
  templateUrl: './history-cart.page.html',
  styleUrls: ['./history-cart.page.scss'],
})
export class HistoryCartPage implements OnInit {

  dataPayment: any = [];
  dataMember: any = [];
  IdMemberStorage:any;
  imageBaseUrl = environment.imageUrl;
  webServiceUrl = environment.baseUrl;

  constructor(
    private http: HttpClient,
    public router:Router,
    private loadingCtral: LoadingController,
    public authenService: AuthenticationService,
    private storage: Storage,
    private route: ActivatedRoute,
  ) {}

 /*ionViewWillEnter() {
    this.getPayment();
  }*/

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    this.getPayment(id);
  }

  /** list data payment **/
  async getPayment(id:any) {
    const loading = await this.loadingCtral.create({
      message: 'Loading...',
      spinner: 'bubbles',
    });
    await loading.present();

    this.storage.get('storage_member').then((val) => {
      this.dataMember = val;
    });
    this.http
      .get(this.webServiceUrl + '/ws_list_payment.php?var_id_member='+id)
      .subscribe((res) => {
        this.dataPayment = res;
      });

      loading.dismiss();
  }
  /** select id member from storage **/
  getMemberStorage() {
    this.storage.get('storage_member').then((val) => {
      this.dataMember = val;
      return this.dataMember.id_member;
    });
  }

  detailHistoryCart(id_payment:number){
    this.router.navigate(['/detailhistory-cart',id_payment]);
  }

  gotoBack(){
    this.router.navigate(['/tabs/tab-account']);
  }
}
